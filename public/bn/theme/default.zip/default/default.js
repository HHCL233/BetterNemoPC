Theme.metaData = {
    "name": "默认",
    "author": "BetterNemo",
    "description": "BetterNemo的默认主题",
    "version": "1.0.0"
}