Theme.metaData = {
    "name": "原版",
    "author": "Codemao(tL7fK5sT.sb 还原)",
    "description": "NewNemo的默认主题",
    "version": "5.10.0"
}